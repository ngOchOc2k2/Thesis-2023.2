from dataloaders.data_loader import get_data_loader
from dataloaders.sampler import data_sampler
 
data = data_sampler()